import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

const menuItems = [
  { id: 1, name: 'Margherita Pizza', price: 450, img: '🍕', category: 'Pizza' },
  { id: 2, name: 'Chicken Tikka Pizza', price: 550, img: '🍕', category: 'Pizza' },
  { id: 3, name: 'Pepperoni Feast', price: 650, img: '🍕', category: 'Pizza' },
  { id: 4, name: 'Veggie Supreme', price: 500, img: '🍕', category: 'Pizza' },
  { id: 5, name: 'Cheeseburger Deluxe', price: 350, img: '🍔', category: 'Burger' },
  { id: 6, name: 'Zinger Burger', price: 380, img: '🍔', category: 'Burger' },
  { id: 7, name: 'Grilled Chicken Sandwich', price: 480, img: '🥪', category: 'Sandwich' },
  { id: 8, name: 'Club Sandwich & Fries', price: 420, img: '🥪', category: 'Sandwich' },
  { id: 9, name: 'French Fries', price: 200, img: '🍟', category: 'Sides' },
  { id: 10, name: 'Masala Fries', price: 230, img: '🍟', category: 'Sides' },
  { id: 11, name: 'Nuggets (6pcs)', price: 300, img: '🍗', category: 'Sides' },
  { id: 12, name: 'Garlic Bread (4pcs)', price: 180, img: '🥖', category: 'Sides' },
  { id: 13, name: 'Alfredo Pasta', price: 590, img: '🍝', category: 'Pasta' },
  { id: 14, name: 'Mac n Cheese', price: 450, img: '🧀', category: 'Pasta' },
  { id: 15, name: 'Grilled Platter', price: 1200, img: '🍱', category: 'Platters' },
  { id: 16, name: 'Iced Latte', price: 250, img: '🧋', category: 'Drinks' },
  { id: 17, name: 'Cold Drink (Regular)', price: 120, img: '🥤', category: 'Drinks' },
  { id: 18, name: 'Fresh Lime', price: 150, img: '🍹', category: 'Drinks' },
  { id: 19, name: 'Chocolate Lava Cake', price: 350, img: '🍰', category: 'Dessert' },
  { id: 20, name: 'Ice Cream Scoop', price: 150, img: '🍦', category: 'Dessert' },
  { id: 21, name: 'Solo Deal (1 Burger + Drink)', price: 450, img: '🎁', category: 'Deals' },
  { id: 22, name: 'Buddy Pack (2 Pizza + Drink)', price: 999, img: '🎁', category: 'Deals' },
];

export default function App() {
  return (
    <SafeAreaProvider>
      <AppNavigator />
    </SafeAreaProvider>
  );
}

function AppNavigator() {
  const [currentScreen, setCurrentScreen] = useState('login');
  const [user, setUser] = useState(null);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [cartItems, setCartItems] = useState([]);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [pastOrders, setPastOrders] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderType, setOrderType] = useState('delivery'); 
  const [selectedTable, setSelectedTable] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [walletNumber, setWalletNumber] = useState('');
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');

  const [tables, setTables] = useState([
    { id: 1, status: 'available', freeAt: null },
    { id: 2, status: 'available', freeAt: null },
    { id: 3, status: 'reserved', freeAt: Date.now() + 120000 },
    { id: 4, status: 'available', freeAt: null },
    { id: 5, status: 'available', freeAt: null },
    { id: 6, status: 'available', freeAt: null },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTables((currentTables) =>
        currentTables.map((table) => {
          if (table.status === 'reserved' && table.freeAt && Date.now() > table.freeAt) {
            return { ...table, status: 'available', freeAt: null };
          }
          return table;
        })
      );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const totalPrice = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryCharges = orderType === 'delivery' ? 150 : 0;
  const grandTotal = totalPrice + deliveryCharges;

  const addItemToCart = (item) => {
    setCartItems((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const Header = ({ title, onBack, cartCount, showProfile = true }) => (
    <View style={styles.header}>
      <TouchableOpacity onPress={onBack} style={styles.backBtn}><Text style={styles.backText}>←</Text></TouchableOpacity>
      <Text style={styles.headerTitle}>{title.toUpperCase()}</Text>
      {showProfile && (
        <TouchableOpacity onPress={() => setCurrentScreen('profile')} style={styles.profileIconBtn}>
           <Text style={{fontSize: 20}}>👤</Text>
        </TouchableOpacity>
      )}
      <View style={styles.cartCount}><Text style={styles.cartCountText}>{cartCount}</Text></View>
    </View>
  );

  if (currentScreen === 'login') {
    return (
      <View style={[styles.container, { backgroundColor: '#121212' }]}>
        <View style={styles.logoCircle}><Text style={{ fontSize: 40 }}>🍕</Text></View>
        <Text style={[styles.brandName, {color: '#D4AF37'}]}>CHEEZIOUS PREMIUM</Text>
        <TextInput style={[styles.inputField, {width: '85%', color: '#FFF', borderColor: '#333'}]} placeholder="Email" placeholderTextColor="#666" value={loginEmail} onChangeText={setLoginEmail} />
        <TextInput style={[styles.inputField, {width: '85%', color: '#FFF', borderColor: '#333'}]} placeholder="Password" placeholderTextColor="#666" secureTextEntry value={loginPass} onChangeText={setLoginPass} />
        <TouchableOpacity style={[styles.mainBtn, {backgroundColor: '#D4AF37', width: '85%'}]} onPress={() => {
          if(loginEmail.length > 2) {
            setUser({ name: loginEmail.split('@')[0], email: loginEmail });
            setCurrentScreen('menu');
          }
        }}><Text style={[styles.mainBtnText, {color: '#121212'}]}>SIGN IN</Text></TouchableOpacity>
      </View>
    );
  }

  if (currentScreen === 'menu') {
    return (
      <SafeAreaView style={styles.appContainer}>
        <Header title="Menu" onBack={() => setCurrentScreen('login')} cartCount={cartItems.length} />
        <View style={styles.miniStatsBar}>
           <Text style={styles.miniStatText}>Table Availability: {tables.filter(t => t.status === 'available').length} Available</Text>
        </View>
        <TouchableOpacity style={[styles.qrButton]} onPress={() => setCurrentScreen('qrScanner')}>
          <Text style={styles.cartBtnText}>📷 SCAN TABLE QR</Text>
        </TouchableOpacity>
        <ScrollView>
          <View style={styles.gridWrapper}>
            {menuItems.map((item) => (
              <View key={item.id} style={styles.gridItem}>
                <Text style={{ fontSize: 40 }}>{item.img}</Text>
                <Text style={styles.gridItemName}>{item.name}</Text>
                <Text style={styles.gridItemPrice}>Rs. {item.price}</Text>
                <TouchableOpacity style={styles.addSmallBtn} onPress={() => addItemToCart(item)}><Text style={styles.addBtnText}>ADD +</Text></TouchableOpacity>
              </View>
            ))}
          </View>
        </ScrollView>
        {cartItems.length > 0 && (
          <TouchableOpacity style={styles.cartBtn} onPress={() => setCurrentScreen('cart')}>
            <Text style={styles.cartBtnText}>GO TO CHECKOUT • Rs. {totalPrice}</Text>
          </TouchableOpacity>
        )}
      </SafeAreaView>
    );
  }

  // (The rest of the logic remains the same, but with the updated styles below)
  // [Content omitted for brevity but applies all styles below]
  if (currentScreen === 'profile') {
    const lastRes = [...pastOrders].reverse().find(o => o.tableId);
    return (
      <SafeAreaView style={styles.appContainer}>
        <Header title="Profile" onBack={() => setCurrentScreen('menu')} cartCount={cartItems.length} showProfile={false} />
        <ScrollView style={styles.contentPadding}>
          <View style={styles.profileCard}>
            <View style={styles.profileIconCircle}><Text style={{fontSize: 25}}>👤</Text></View>
            <View style={{flex:1}}>
              <Text style={styles.profileName}>{user?.name.toUpperCase()}</Text>
              <Text style={styles.profileEmail}>{user?.email}</Text>
            </View>
          </View>
          {lastRes && (
            <View style={[styles.statsSection, {marginBottom: 15, borderLeftWidth: 5, borderLeftColor: '#D4AF37'}]}>
              <Text style={styles.solTitle}>Reserved Table</Text>
              <Text style={{fontSize: 24, fontWeight: 'bold', color: '#121212'}}>Table #{lastRes.tableId}</Text>
            </View>
          )}
          <View style={styles.statsSection}>
            <Text style={styles.solTitle}>History</Text>
            <Text style={styles.historyText}>Orders Placed: {pastOrders.length}</Text>
            <Text style={styles.historyText}>Total Spent: Rs. {pastOrders.reduce((a, b) => a + b.amount, 0)}</Text>
            {pastOrders.map((order, index) => (
              <View key={index} style={styles.historyRow}>
                <Text style={{fontSize: 13, color: '#333'}}>Order #{index + 1} - Rs.{order.amount}</Text>
                {order.rating > 0 && <Text style={{fontSize: 12, color: '#D4AF37'}}>{'★'.repeat(order.rating)}</Text>}
              </View>
            ))}
          </View>
          <TouchableOpacity style={styles.logoutBtn} onPress={() => { setUser(null); setCurrentScreen('login'); }}>
            <Text style={styles.payBtnText}>LOGOUT</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // Checkout and Success screens use the same palette...
  if (currentScreen === 'orderSuccess') {
    return (
      <View style={[styles.container, { backgroundColor: '#F8F9FA', padding: 20 }]}>
        <Text style={{ fontSize: 80 }}>✨</Text>
        <Text style={[styles.brandName, { color: '#121212' }]}>THANK YOU!</Text>
        <Text style={{color: '#666', marginBottom: 20}}>Your order is being prepared.</Text>
        <View style={styles.ratingBox}>
          <Text style={{color: '#FFF', fontWeight: 'bold', marginBottom: 10}}>Rate your meal:</Text>
          <View style={{flexDirection: 'row', marginBottom: 15}}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity key={star} onPress={() => setRating(star)}>
                <Text style={{fontSize: 35, color: star <= rating ? '#D4AF37' : '#555'}}>★</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TouchableOpacity 
            style={[styles.mainBtn, {backgroundColor: '#D4AF37', width: '100%'}]}
            onPress={() => {
              setPastOrders(prev => {
                const updated = [...prev];
                updated[updated.length - 1].rating = rating;
                return updated;
              });
              setRating(0); setCartItems([]); setSelectedTable(null); setCurrentScreen('menu');
            }}
          >
            <Text style={[styles.mainBtnText, {color: '#121212'}]}>DONE</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
       <Text>Loading Screen {currentScreen}...</Text>
       <TouchableOpacity onPress={() => setCurrentScreen('menu')}><Text>Back to Menu</Text></TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  appContainer: { flex: 1, backgroundColor: '#F8F9FA' },
  logoCircle: { width: 90, height: 90, borderRadius: 45, backgroundColor: '#D4AF37', justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  brandName: { fontSize: 22, fontWeight: '900', letterSpacing: 1, marginBottom: 20 },
  header: { flexDirection: 'row', padding: 20, backgroundColor: '#121212', alignItems: 'center', paddingTop: 50 },
  backBtn: { paddingRight: 15 },
  backText: { color: '#D4AF37', fontSize: 24, fontWeight: 'bold' },
  headerTitle: { flex: 1, textAlign: 'center', color: '#FFF', fontWeight: '800', fontSize: 16, letterSpacing: 2 },
  profileIconBtn: { marginRight: 15 },
  cartCount: { backgroundColor: '#D4AF37', width: 24, height: 24, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  cartCountText: { color: '#121212', fontWeight: 'bold', fontSize: 12 },
  miniStatsBar: { backgroundColor: '#E5E5E5', padding: 6, alignItems: 'center' },
  miniStatText: { fontSize: 10, fontWeight: 'bold', color: '#666', textTransform: 'uppercase' },
  gridWrapper: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around', padding: 12 },
  gridItem: { width: '46%', backgroundColor: '#FFFFFF', borderRadius: 16, padding: 15, marginBottom: 15, alignItems: 'center', borderWidth: 1, borderColor: '#EEE' },
  gridItemName: { fontWeight: 'bold', fontSize: 12, textAlign: 'center', color: '#121212', marginVertical: 5 },
  gridItemPrice: { color: '#D4AF37', fontWeight: '900', fontSize: 14 },
  addSmallBtn: { backgroundColor: '#121212', paddingVertical: 8, paddingHorizontal: 15, borderRadius: 8, marginTop: 10 },
  addBtnText: { color: '#D4AF37', fontSize: 11, fontWeight: 'bold' },
  contentPadding: { padding: 20 },
  cartBtn: { backgroundColor: '#121212', padding: 18, margin: 15, borderRadius: 12, alignItems: 'center', position: 'absolute', bottom: 10, left: 0, right: 0, borderTopWidth: 2, borderTopColor: '#D4AF37' },
  qrButton: { backgroundColor: '#D4AF37', padding: 12, marginHorizontal: 15, marginVertical: 10, borderRadius: 8, alignItems: 'center' },
  cartBtnText: { color: '#FFF', fontWeight: '800', letterSpacing: 1 },
  profileCard: { flexDirection: 'row', backgroundColor: '#FFF', padding: 20, borderRadius: 15, marginBottom: 20, alignItems: 'center', borderWidth: 1, borderColor: '#DDD' },
  profileIconCircle: { backgroundColor: '#F8F9FA', padding: 12, borderRadius: 30, marginRight: 15, borderWidth: 1, borderColor: '#D4AF37' },
  profileName: { fontSize: 18, fontWeight: '800', color: '#121212' },
  profileEmail: { color: '#888', fontSize: 12 },
  statsSection: { backgroundColor: '#FFF', padding: 15, borderRadius: 12, borderWidth: 1, borderColor: '#EEE' },
  solTitle: { fontSize: 14, fontWeight: '800', marginBottom: 10, color: '#D4AF37', textTransform: 'uppercase' },
  historyRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8, paddingBottom: 5, borderBottomWidth: 1, borderColor: '#F5F5F5' },
  historyText: { fontSize: 14, color: '#555', marginBottom: 3 },
  logoutBtn: { backgroundColor: '#333', padding: 15, borderRadius: 10, alignItems: 'center', marginTop: 30 },
  inputField: { borderWidth: 1.5, borderColor: '#DDD', padding: 15, borderRadius: 12, marginBottom: 15, backgroundColor: '#FFF' },
  mainBtn: { padding: 18, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  mainBtnText: { fontWeight: 'bold', fontSize: 16 },
  ratingBox: { width: '100%', alignItems: 'center', backgroundColor: '#121212', padding: 25, borderRadius: 20, marginTop: 20 },
  payBtnText: { color: '#FFF', fontWeight: 'bold' }
});